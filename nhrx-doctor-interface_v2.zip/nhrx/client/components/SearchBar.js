'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { isValidCnic, normalizeCnic } from '../lib/cnic';

export default function SearchBar({ initial = '', large = false }) {
  const [cnic, setCnic] = useState(initial);
  const [error, setError] = useState('');
  const router = useRouter();
  const submit = (e) => {
    e.preventDefault();
    if (!isValidCnic(cnic)) { setError('Enter a valid CNIC in the format 12345-1234567-1'); return; }
    setError('');
    router.push(`/patient/${encodeURIComponent(normalizeCnic(cnic))}`);
  };
  return (
    <form onSubmit={submit} className="w-full">
      <div className="flex w-full gap-2">
        <input
          className={`input ${large ? 'py-3 text-base' : ''}`}
          placeholder="Enter Patient CNIC (e.g. 35202-1234567-1)"
          value={cnic}
          maxLength={15}
          onChange={(e) => { setCnic(e.target.value); if (error) setError(''); }}
        />
        <button className={`btn ${large ? 'px-6' : ''}`}>Search</button>
      </div>
      {error && <p className="mt-1 text-sm text-red-600">{error}</p>}
    </form>
  );
}
