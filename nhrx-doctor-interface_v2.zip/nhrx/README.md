# NHRX — Doctor Interface

Monolithic full-stack app: **Next.js 14 + Tailwind** (client) · **Express** (server) · **PostgreSQL (node-postgres `pg`)** — no Prisma CLI, no migrations.

## Setup
```bash
# 1. Server
cd server
# .env is pre-filled with the team cloud DATABASE_URL; set JWT_SECRET + ENCRYPTION_KEY
npm install
npm run dev                   # connects, creates tables if missing, seeds if empty → http://localhost:4000

# 2. Client
cd ../client
npm install
npm run dev                   # http://localhost:3000
```
Generate an encryption key: `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`

## Database auto-sync
On startup `server/src/db.js` checks for the `"User"` and `"MedicalCase"` tables and runs
`CREATE TABLE IF NOT EXISTS` for anything missing. With `AUTO_SEED=true`, sample doctors/cases are
inserted only when the `User` table is empty. `GET /api/health` reports DB connectivity.

> The `#` in the DB password is written as `%23` in `DATABASE_URL` — required for URL parsing.
> All teammates must share the same `ENCRYPTION_KEY`, or each other's rows read as `[Unable to decrypt]`.

## CNIC validation
Format `12345-1234567-1` (13 digits also accepted and auto-formatted). Enforced in the search bar and in the API.

## Seeded doctors (password: `password123`)
| Doctor | Email | Hospital |
|---|---|---|
| Dr. Ayesha Khan | ayesha@hospital1.pk | Hospital 1 |
| Dr. Bilal Ahmed | bilal@hospital1.pk | Hospital 1 |
| Dr. Sara Malik | sara@hospital2.pk | Hospital 2 |
| Dr. Usman Raza | usman@hospital2.pk | Hospital 2 |

Sample patient CNICs: `35202-1234567-1`, `42101-7654321-3`

## Security
`diagnosis` and `treatment` are encrypted with AES-256-GCM (`server/src/utils/crypto.js`) before writing to PostgreSQL and decrypted only inside authenticated (JWT) routes — Decrypt-on-Read.
