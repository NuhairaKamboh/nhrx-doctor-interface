// Optional manual seed: npm run seed
const { initDb, pool } = require('../src/db');
const { seedIfEmpty } = require('../src/seedData');
initDb().then(seedIfEmpty).catch((e) => { console.error(e); process.exitCode = 1; }).finally(() => pool.end());
