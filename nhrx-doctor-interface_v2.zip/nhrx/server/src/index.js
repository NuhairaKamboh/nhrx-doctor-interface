require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { initDb, query } = require('./db');
const { seedIfEmpty } = require('./seedData');

const app = express();
app.use(cors({ origin: process.env.CLIENT_ORIGIN || 'http://localhost:3000' }));
app.use(express.json());

app.get('/api/health', async (_req, res) => {
  try { await query('SELECT 1'); res.json({ ok: true, db: 'connected' }); }
  catch (e) { res.status(503).json({ ok: false, db: e.message }); }
});
app.use('/api/auth', require('./routes/auth'));
app.use('/api/cases', require('./routes/cases'));

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: 'Internal server error' });
});

const PORT = process.env.PORT || 4000;

(async () => {
  try {
    await initDb(); // creates "User" and "MedicalCase" if missing
    if (process.env.AUTO_SEED === 'true') await seedIfEmpty();
    app.listen(PORT, () => console.log(`NHRX API running on http://localhost:${PORT}`));
  } catch (err) {
    console.error('[startup] could not connect/initialize database:', err.message);
    process.exit(1);
  }
})();
