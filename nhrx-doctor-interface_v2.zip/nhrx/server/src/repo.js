// Data access layer: Encrypt-on-Write / Decrypt-on-Read for MedicalCase
const { query } = require('./db');
const { encryptCase, decryptCase } = require('./utils/crypto');

const CASE_SELECT = `
  SELECT c.*, u."doctorName" AS "_doctorName", u."hospitalName" AS "_doctorHospital"
  FROM "MedicalCase" c JOIN "User" u ON u."id" = c."doctorId"`;

// Shape rows like the old Prisma `include: { doctor }` so the frontend is unchanged
function shape(row) {
  if (!row) return null;
  const { _doctorName, _doctorHospital, ...rest } = row;
  return decryptCase({ ...rest, doctor: { doctorName: _doctorName, hospitalName: _doctorHospital } });
}

const users = {
  findByEmail: async (email) => (await query('SELECT * FROM "User" WHERE "email" = $1', [email])).rows[0],
  count: async () => Number((await query('SELECT COUNT(*) FROM "User"')).rows[0].count),
  create: async ({ doctorName, email, password, hospitalName }) =>
    (await query(
      'INSERT INTO "User" ("doctorName","email","password","hospitalName") VALUES ($1,$2,$3,$4) RETURNING *',
      [doctorName, email, password, hospitalName],
    )).rows[0],
};

const cases = {
  async findByCnic(cnic) {
    const { rows } = await query(`${CASE_SELECT} WHERE c."patientCnic" = $1 ORDER BY c."checkupDate" DESC`, [cnic]);
    return rows.map(shape);
  },
  async findRawById(id) {
    return (await query('SELECT * FROM "MedicalCase" WHERE "id" = $1', [id])).rows[0];
  },
  async findById(id) {
    return shape((await query(`${CASE_SELECT} WHERE c."id" = $1`, [id])).rows[0]);
  },
  async create(data) {
    const d = encryptCase(data);
    const { rows } = await query(
      `INSERT INTO "MedicalCase"
        ("patientCnic","hospitalName","diagnosis","treatment","medicines","caseStatus","checkupDate","doctorId")
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING "id"`,
      [d.patientCnic, d.hospitalName, d.diagnosis, d.treatment, d.medicines || '', d.caseStatus || 'PENDING',
       d.checkupDate || new Date(), d.doctorId],
    );
    return cases.findById(rows[0].id);
  },
  async updateStatus(id, caseStatus) {
    await query('UPDATE "MedicalCase" SET "caseStatus" = $1 WHERE "id" = $2', [caseStatus, id]);
    return cases.findById(id);
  },
};

module.exports = { users, cases };
