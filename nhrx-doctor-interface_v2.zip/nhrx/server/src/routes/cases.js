const router = require('express').Router();
const { cases } = require('../repo');
const { requireAuth } = require('../middleware/auth');
const { isValidCnic, normalizeCnic } = require('../utils/cnic');

const STATUSES = ['PENDING', 'COMPLETED'];
// Wrap async handlers so DB errors reach the error middleware (Express 4)
const wrap = (fn) => (req, res, next) => fn(req, res, next).catch(next);

router.use(requireAuth);

// GET /api/cases/:cnic — full cross-hospital timeline (decrypt-on-read)
router.get('/:cnic', wrap(async (req, res) => {
  if (!isValidCnic(req.params.cnic)) return res.status(400).json({ error: 'Invalid CNIC format (expected 12345-1234567-1)' });
  res.json(await cases.findByCnic(normalizeCnic(req.params.cnic)));
}));

// POST /api/cases — log a new case at the doctor's hospital (encrypt-on-write)
router.post('/', wrap(async (req, res) => {
  const { patientCnic, diagnosis, treatment, medicines, caseStatus = 'PENDING', checkupDate } = req.body;
  if (!patientCnic || !diagnosis || !treatment) {
    return res.status(400).json({ error: 'patientCnic, diagnosis and treatment are required' });
  }
  if (!isValidCnic(patientCnic)) return res.status(400).json({ error: 'Invalid CNIC format (expected 12345-1234567-1)' });
  const created = await cases.create({
    patientCnic: normalizeCnic(patientCnic),
    diagnosis, treatment,
    medicines: medicines || '',
    caseStatus: STATUSES.includes(caseStatus) ? caseStatus : 'PENDING',
    checkupDate: checkupDate ? new Date(checkupDate) : new Date(),
    hospitalName: req.doctor.hospitalName,
    doctorId: req.doctor.id,
  });
  res.status(201).json(created);
}));

// PATCH /api/cases/:id/status — PENDING <-> COMPLETED (owner doctor only)
router.patch('/:id/status', wrap(async (req, res) => {
  const { caseStatus } = req.body;
  if (!STATUSES.includes(caseStatus)) return res.status(400).json({ error: 'Invalid status' });
  const existing = await cases.findRawById(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Case not found' });
  if (existing.doctorId !== req.doctor.id) return res.status(403).json({ error: 'Only the treating doctor can update status' });
  res.json(await cases.updateStatus(req.params.id, caseStatus));
}));

module.exports = router;
