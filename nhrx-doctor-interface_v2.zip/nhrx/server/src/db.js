// PostgreSQL connection + automatic table sync (no Prisma CLI / migrations needed)
require('dotenv').config();
const { Pool } = require('pg');

const pool = new Pool({ connectionString: process.env.DATABASE_URL, max: 10 });
pool.on('error', (err) => console.error('[db] idle client error:', err.message));

const query = (text, params) => pool.query(text, params);

// Table names / columns are quoted so they match the original Prisma layout exactly.
const SCHEMA_SQL = `
CREATE TABLE IF NOT EXISTS "User" (
  "id"           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "doctorName"   TEXT NOT NULL,
  "email"        TEXT NOT NULL UNIQUE,
  "password"     TEXT NOT NULL,
  "hospitalName" TEXT NOT NULL,
  "createdAt"    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "MedicalCase" (
  "id"           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "patientCnic"  TEXT NOT NULL,
  "hospitalName" TEXT NOT NULL,
  "diagnosis"    TEXT NOT NULL,   -- AES-256-GCM ciphertext
  "treatment"    TEXT NOT NULL,   -- AES-256-GCM ciphertext
  "medicines"    TEXT NOT NULL DEFAULT '',
  "caseStatus"   TEXT NOT NULL DEFAULT 'PENDING' CHECK ("caseStatus" IN ('PENDING','COMPLETED')),
  "checkupDate"  TIMESTAMPTZ NOT NULL DEFAULT now(),
  "doctorId"     UUID NOT NULL REFERENCES "User"("id") ON DELETE CASCADE,
  "createdAt"    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS "MedicalCase_patientCnic_idx" ON "MedicalCase"("patientCnic");
`;

async function tableExists(name) {
  const { rows } = await query('SELECT to_regclass($1) AS t', [`public."${name}"`]);
  return rows[0].t !== null;
}

async function initDb() {
  await query('SELECT 1'); // fail fast if the server is unreachable
  const before = { User: await tableExists('User'), MedicalCase: await tableExists('MedicalCase') };
  await query('CREATE EXTENSION IF NOT EXISTS pgcrypto').catch(() => {}); // gen_random_uuid on PG < 13
  await query(SCHEMA_SQL);
  for (const [t, existed] of Object.entries(before)) {
    console.log(`[db] table "${t}" ${existed ? 'already exists' : 'created'}`);
  }
}

module.exports = { pool, query, initDb };
