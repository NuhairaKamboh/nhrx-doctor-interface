// Task 4 — Pakistani CNIC validation (#####-#######-#)
const CNIC_REGEX = /^\d{5}-\d{7}-\d$/;
function normalizeCnic(input) {
  const digits = String(input || '').replace(/\D/g, '');
  return digits.length === 13 ? `${digits.slice(0, 5)}-${digits.slice(5, 12)}-${digits.slice(12)}` : String(input || '').trim();
}
const isValidCnic = (v) => CNIC_REGEX.test(normalizeCnic(v));
module.exports = { CNIC_REGEX, normalizeCnic, isValidCnic };
